# College-Event-Management-System
### Project Title: College Event Management System 
### Programming Language: HTML, CSS, MySQL, Php 
### Project Description: Designing and Hosting College event management system. On this platform students can create profile, look through the event lists, register for the events and organizers can maintain the event registrations. 
### Link: https://collegeeventmgmt.000webhostapp.com/
