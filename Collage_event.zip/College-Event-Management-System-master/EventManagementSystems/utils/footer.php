<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>S</strong><span class = "small footerSubtext">ai</span>
                        <strong>V</strong><span class = "small footerSubtext">idya</span>
                        <strong>I</strong><span class = "small footerSubtext">nstitue of</span>
                        <strong>T</strong><span class = "small footerSubtext">echnology</span>
                    </p>

                    <p class = "footerSubtext2">
                    Our college Mission is to impart quality technical education and higher moral ethics associated with skilled training to suit the modern day technology with innovative concepts,so as to learn to lead the future with full confidence
                  .
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                <p> <br>
                 Address: Rajanukunte
                    via Yelahanka
                    <br>Bengaluru, Karnataka 560064 </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                    <a href="https://www.facebook.com/SaiVidyaInstituteOfTechnology/"><img src = "images/facebook.png"></a>
                    <a href="https://www.instagram.com/sai_vidya_institute_of_tech/"><img src = "images/instagram.png" width="65px"></a>
                        
                        <a href="https://www.youtube.com/channel/UCoiD02xL4iPjwYyHylNZtFw"><img src = "images/youtube.png"></a>
                </div>
            </section>
        </div>
    </div>
</footer>