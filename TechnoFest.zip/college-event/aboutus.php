
</html>
<!DOCTYPE html>
<html>
<?php require 'utils/styles.php'; ?>
<title>About us</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;+
}

*, *:before, *:after {
  box-sizing: inherit;

}

/*body{
  background-color: #474e5d;
}*/
.column {
  float: left;
  width: 25%;
  margin-bottom: 10px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 6px;
}

.about-section {
  padding: 90px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}
.row{
		margin: 4px;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 30	%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
<?php require 'utils/header1.php'; ?>
</head>
<body>

<div class="about-section">
  <h1>Who we are</h1>

  <p style="text-align: justify;"> Welcome to VIIT Event Management System! We are a team of college students who are dedicated to making your college events a success.
      Our team has a deep understanding of the needs and interests of college students, and we are committed to providing exceptional event 
      planning services that meet those needs. We work closely with our college administration and student organizations to create fun and 
      engaging events that reflect the unique culture of our college.<!-- <br> -->
      Our services include event planning, venue selection, vendor management, and marketing. We are passionate about what we do and are committed to delivering outstanding events that exceed your expectations.At VIIT, we believe that events are a great way to bring the college community together and create lasting memories. We are committed to creating events that are not only enjoyable but also provide opportunities for personal growth and development.
Thank you for considering VIIT Event Management System for your college event planning needs. We look forward to working with you to create memorable events that will make your college experience unforgettable.</p>
</div>

<!-- <h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="images/shruti.jpg" alt="Jane" style="width:100%;" >
      <div class="container">
        <h2>Shruti Kamble</h2>
        <p class="title">Member</p>
        <p>B-Tech Second Year</p>
        <p>B-Batch</p>
        <p>shruti.22220169@viit.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="images/dhanashri.jpeg" alt="Mike" style="width:100%">
      <div class="container">
        <h2>Dhanashri Mahale</h2>
        <p class="title">Member</p>
        <p>B-Tech Second Year</p>
        <p>B-Batch</p>
        <p>dhanashri.2222088@viit.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="images/pritam.jpeg" alt="John" style="width:100%">
      <div class="container">
        <h2>Pritam Dhahiphale</h2>
        <p class="title">Member</p>
        <p>B-Tech Second Year</p>
        <p>B-Batch</p>
        <p>pritam.2222044@viit.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

   <div class="column">
    <div class="card">
      <img src="images/muskan.jpeg" alt="John" style="width:100%">
      <div class="container">
        <h2>Muskan Shaikh</h2>
        <p class="title">Member</p>
        <p>B-Tech Second Year</p>
        <p>B-Batch</p>
        <p>muskan.22220287@viit.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div> -->
<?php require 'utils/footer.php'; ?>
</body>
</html>
