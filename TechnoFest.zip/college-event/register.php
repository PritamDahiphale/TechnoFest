
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register</title>
        <?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
        <style type="text/css">
          .content{
              margin-top: 10%;
          }

            .update {
                  background: #5E5DF0;
                  border-radius: 999px;
                  box-shadow: #5E5DF0 0 10px 20px -10px;
                  box-sizing: border-box;
                  color: #FFFFFF;
                  cursor: pointer;
                  font-family: Inter,Helvetica,"Apple Color Emoji","Segoe UI Emoji",NotoColorEmoji,"Noto Color Emoji","Segoe UI Symbol","Android Emoji",EmojiSymbols,-apple-system,system-ui,"Segoe UI",Roboto,"Helvetica Neue","Noto Sans",sans-serif;
                  font-size: 16px;
                  font-weight: 700;
                  line-height: 24px;
                  opacity: 1;
                  outline: 0 solid transparent;
                  padding: 8px 18px;
                  user-select: none;
                  -webkit-user-select: none;
                  touch-action: manipulation;
                  width: fit-content;
                  word-break: break-word;
                  border: 0;
                }
        
        </style>

    </head>
    <?php require 'utils/header1.php'; ?>
    <body>
    
    <div class ="content"><!--body content holder-->
      <div class="row">
            <div class = "container">
               <h1 align="CENTER" style="color: #330099;"><b>REGISTER !!</b></h1>
                <div class ="col-md-6 col-md-offset-3">

    <form method="POST">

   
        <label>STUDENT GR.NO</label><br>
        <input type="text" name="usn" class="form-control" placeholder="Enter GR number" required><br><br>

        <label>STUDENT NAME:</label><br>
        <input type="text" name="name" class="form-control" placeholder="Enter name" required><br><br>

        <label>BRANCH</label><br>
        <input type="text" name="branch" class="form-control" placeholder="Enter branch" required><br><br>

        <label>SEMESTER</label><br>
        <input type="text" name="sem" class="form-control" placeholder="Enter semester" required><br><br>

        <label >EMAIL</label><br>
        <input type="text" name="email"  class="form-control" placeholder="Enter email"  required ><br><br>

        <label>PHONE</label><br>
        <input type="text" name="phone"  class="form-control" placeholder="Enter phone number" required><br><br>

        <label>COLLEGE</label><br>
        <input type="text" name="college"  class="form-control" placeholder="Enter name of college" required><br><br>

        <button type="submit" name="update" class="update" required>Submit</button><br><br>
        <a href="usn.php" ><u>Already registered ?</u></a>

    </div>
    </div>
    </div>
    </div>
    </form>
    

    <?php require 'utils/footer.php'; ?>
    </body>
</html>

<?php

    if (isset($_POST["update"]))
    {
        $usn=$_POST["usn"];
        $name=$_POST["name"];
        $branch=$_POST["branch"];
        $sem=$_POST["sem"];
        $email=$_POST["email"];
        $phone=$_POST["phone"];
        $college=$_POST["college"];


        if( !empty($usn) || !empty($name) || !empty($branch) || !empty($sem) || !empty($email) || !empty($phone) || !empty($college) )
        {
        
            include 'classes/db1.php';     
                $INSERT="INSERT INTO participent (usn,name,branch,sem,email,phone,college) VALUES('$usn','$name','$branch',$sem,'$email','$phone','$college')";

          
                if($conn->query($INSERT)===True){
                    echo "<script>
                    alert('Registered Successfully!');
                    window.location.href='usn.php';
                    </script>";
                }
                else
                {
                    echo"<script>
                    alert(' Already registered this usn');
                    window.location.href='usn.php';
                    </script>";
                }
               
                $conn->close();
            
        }
        else
        {
            echo"<script>
            alert('All fields are required');
            window.location.href='register.php';
                    </script>";
        }
    }
    
?>